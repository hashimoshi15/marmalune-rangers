# Marmalune Rangers — version history

Version numbers follow `MAJOR.MINOR.PATCH`. The title screen shows the version and the
source commit of the build (for example `v1.2.0 · 1a2b3c4`). Builds made from a working tree
with uncommitted changes show `-dev` after the commit.

## 1.2.0 — rangers, a friendlier first visit, and play anywhere
- Four original rangers to pick in the new Ranger Locker, with cosmetics you can see in play: gauntlet colours,
  Beepo hats, dash trails, gold trims and skiff paint.
- A friendlier start: a loading screen in your language, a short first mission that begins near a robot camp, and
  Fizzport facilities that open step by step over the first four missions (existing saves keep everything).
- Results list every reward you earned, rank-up bonuses included, with Next mission / Next boss buttons; a
  "New in Fizzport!" card shows what just opened and takes you there.
- The Mission Board explains why a mission is still locked and what each medal needs.
- Sound and music overhaul: smooth music changes between places, ambience everywhere, footsteps that match the
  ground, warning sounds before enemy attacks, a heartbeat at low health, and Ambience / Menu sound sliders.
- Sound captions that show where a sound comes from (they also work with the sound off).
- Text & UI size (S to XL), comfort options (screen shake, flashes, speed lines, camera bob) and a crosshair you
  can restyle.
- Gamepad support in menus and in play, with matching button hints; on a controller the first-run control cards
  offer aim help only (no touch auto-fire).
- Sturdier saves: automatic backup, a recovery screen if a save is damaged, and save codes to move your progress to
  another browser or device (Settings → Game → Save code).
- Combat: a horizontal field-of-view setting, the glowing battery on robots is a real weak spot, clearer enemy
  wind-ups and boss callouts.
- Modes: Fountain Guard has planned waves with mini-bosses and a next-wave preview; the Rally has corner signs,
  checkpoints and personal bests; Goo Turf has team patterns and a final-minute Goo Rush; Skydrop Royale is clearly
  you against 15 bots, with landing tips and a ring timer.
- Every region has its own landmark and scenery, and Fizzport's signs and doors are easier to read.
- New Ultra graphics for strong computers (sun shadows, richer glow, denser plants, sharper textures); Low, Medium
  and High run as before.
- The web version can be installed like an app, plays offline after the first visit, and tells you when a new
  version is ready (never in the middle of a mission); full-screen button and an iPhone home-screen tip.
- Offline download: a ZIP you can unpack and play from a folder without internet.
- Small phones and big text: results fit the screen (short reward chips, rank bar kept in view, a "more" button),
  messages never cover the results buttons, pickups stay off the objective, captions stay off the crosshair,
  left-handed buttons stay inside the screen and the pause menu fits.
- Calmer café and shop wording (nothing asks you to come back every day); leaving during a win's celebration keeps
  the win; daily and weekly boards never list the same goal twice.

## 1.1.0 — smoothness & quality pass
- Steadier frame pacing, no shader hitches after loading, resolution changes without stutter.
- Anti-aliasing, soft glow and colour grading on Medium/High graphics.
- Smoother touch look (optional toggle), spring camera and weapon motion.
- Menu, HUD, loading-screen and button animations.
- Character and enemy animation blending, hit reactions, pop effects.
- Richer impacts, explosions, muzzle flashes and pickups.
- Swaying grass and flowers, ambient life, water foam, per-place lighting, glossy turf ink.
- Space race: banking, spring camera, speed lines, boost/drift effects, visible rings.

## 1.0.0 — first public release
- First build published at https://hashimoshi15.github.io/marmalune-rangers/ (source commit fef8002).
- Earlier preview pages showed a revision number such as "v4"; that was the page's revision count, not the
  game version.
