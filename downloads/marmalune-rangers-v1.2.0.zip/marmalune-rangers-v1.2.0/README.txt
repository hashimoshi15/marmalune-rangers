Marmalune Rangers v1.2.0 (build 3424d51, 2026-10-17)
==============================================================

【日本語】あそびかた
1. この ZIP を好きな場所に展開（解凍）します。
2. フォルダの中の index.html をブラウザで開きます（ダブルクリック）。
   Chrome / Edge / Safari / Firefox の最新版をおすすめします。
3. インターネットにつながっていなくても遊べます（文字はパソコンの標準フォントになります）。
- セーブデータは、そのブラウザの中に保存されます。別のブラウザや別の端末とは共有されません。
  「せってい」→「ゲーム」→「セーブコード」の「コードをコピー」/「コードを読みこむ」で移せます。
- スマホで遊ぶときは、公開版 https://hashimoshi15.github.io/marmalune-rangers/ がおすすめです。
- ログインや課金はありません。

[English] How to play
1. Unzip this archive anywhere.
2. Open index.html in a browser (double-click). Latest Chrome, Edge, Safari or Firefox recommended.
3. It works offline (text uses your system fonts when there is no internet).
- Progress is saved inside that browser only. To move it, use Settings → Game → Save code (Copy code / Load code).
- On phones, the web version is easier: https://hashimoshi15.github.io/marmalune-rangers/
- No login, no purchases.

Files: index.html (the whole game), CHANGELOG.md (version history), LICENSES.txt (credits & licences).
